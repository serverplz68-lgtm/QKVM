const api = async (url, opts = {}) => {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    ...opts,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
};

function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

let me = null;
const loginView = document.getElementById('login-view');
const appView = document.getElementById('app-view');

async function checkAuth() {
  try {
    me = await api('/api/auth/me');
    if (!me.isAdmin) throw new Error('not admin');
    showApp();
  } catch {
    showLogin();
  }
}

function showLogin() { loginView.classList.remove('hidden'); appView.classList.add('hidden'); }
function showApp() {
  loginView.classList.add('hidden');
  appView.classList.remove('hidden');
  document.getElementById('chip-username').textContent = me.username + (me.isMainAdmin ? ' (main admin)' : '');
  if (!me.isMainAdmin) document.querySelector('.nav-item[data-view="admins"]').classList.add('hidden');
  navigate('overview');
}

document.getElementById('auth-submit').addEventListener('click', async () => {
  const username = document.getElementById('auth-username').value.trim();
  const password = document.getElementById('auth-password').value;
  const errEl = document.getElementById('auth-error');
  errEl.textContent = '';
  try {
    const r = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
    if (!r.isAdmin) { errEl.textContent = 'This account does not have admin privileges.'; return; }
    me = r;
    showApp();
  } catch (e) { errEl.textContent = e.message; }
});

document.getElementById('logout-btn').addEventListener('click', async () => {
  await api('/api/auth/logout', { method: 'POST' });
  location.reload();
});

document.querySelectorAll('.nav-item[data-view]').forEach((el) => el.addEventListener('click', () => navigate(el.dataset.view)));
function setActiveNav(view) {
  document.querySelectorAll('.nav-item[data-view]').forEach((el) => el.classList.toggle('active', el.dataset.view === view));
}

const titles = {
  overview: 'Overview', users: 'Users', vps: 'All VPS', nodes: 'Nodes',
  deployplans: 'Deploy Plans', resourceplans: 'Resource Plans', coupons: 'Coupons',
  security: 'Security Logs', settings: 'Settings', admins: 'Admins',
};

async function navigate(view) {
  setActiveNav(view);
  document.getElementById('view-title').textContent = titles[view] || view;
  const root = document.getElementById('view-root');
  root.innerHTML = '<div class="muted">Loading…</div>';
  try {
    const fn = { overview: renderOverview, users: renderUsers, vps: renderVps, nodes: renderNodes,
      deployplans: renderDeployPlans, resourceplans: renderResourcePlans, coupons: renderCoupons,
      security: renderSecurity, settings: renderSettings, admins: renderAdmins }[view];
    await fn(root);
  } catch (e) {
    root.innerHTML = `<div class="card">Error: ${e.message}</div>`;
  }
}

async function renderOverview(root) {
  const s = await api('/api/admin/stats');
  root.innerHTML = `
    <div class="stat-grid">
      <div class="stat"><div class="label">Users</div><div class="value">${s.users}</div></div>
      <div class="stat"><div class="label">Total VPS</div><div class="value">${s.vps}</div></div>
      <div class="stat"><div class="label">Running</div><div class="value">${s.running}</div></div>
      <div class="stat"><div class="label">Suspended</div><div class="value">${s.suspended}</div></div>
      <div class="stat"><div class="label">Nodes</div><div class="value">${s.nodes}</div></div>
      <div class="stat"><div class="label">Coins in Circulation</div><div class="value">${s.coinsInCirculation}</div></div>
    </div>
  `;
}

async function renderUsers(root) {
  const users = await api('/api/admin/users');
  root.innerHTML = `
    <table>
      <thead><tr><th>Username</th><th>User ID</th><th>Balance</th><th>VPS</th><th>Joined</th><th></th></tr></thead>
      <tbody>${users.map((u) => `
        <tr>
          <td>${u.username}</td><td class="muted">${u.user_id}</td><td>${u.balance}</td><td>${u.vps_count}</td>
          <td class="muted">${new Date(u.created_at).toLocaleDateString()}</td>
          <td class="row" style="gap:4px;">
            <button class="btn small secondary" data-give="${u.user_id}">+Coins</button>
            <button class="btn small secondary" data-remove="${u.user_id}">-Coins</button>
            <button class="btn small secondary" data-restrict="${u.user_id}">Restrict</button>
          </td>
        </tr>`).join('')}
      </tbody>
    </table>
  `;
  root.querySelectorAll('button[data-give]').forEach((btn) => btn.addEventListener('click', async () => {
    const amount = parseInt(prompt('Coins to give:', '100'), 10);
    if (!amount) return;
    await api(`/api/admin/users/${btn.dataset.give}/coins/give`, { method: 'POST', body: JSON.stringify({ amount, reason: 'Admin gift' }) });
    toast('Coins granted'); navigate('users');
  }));
  root.querySelectorAll('button[data-remove]').forEach((btn) => btn.addEventListener('click', async () => {
    const amount = parseInt(prompt('Coins to remove:', '100'), 10);
    if (!amount) return;
    await api(`/api/admin/users/${btn.dataset.remove}/coins/remove`, { method: 'POST', body: JSON.stringify({ amount, reason: 'Admin removal' }) });
    toast('Coins removed'); navigate('users');
  }));
  root.querySelectorAll('button[data-restrict]').forEach((btn) => btn.addEventListener('click', async () => {
    const reason = prompt('Reason for restriction:', 'Admin action') || 'Admin action';
    await api(`/api/admin/users/${btn.dataset.restrict}/restrict`, { method: 'POST', body: JSON.stringify({ reason }) });
    toast('User restricted'); navigate('users');
  }));
}

async function renderVps(root) {
  const [vpsList, nodes] = await Promise.all([api('/api/admin/vps'), api('/api/admin/nodes')]);
  root.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <button class="btn" id="new-vps-btn">+ Create VPS for user</button>
    </div>
    <table>
      <thead><tr><th>Container</th><th>Owner</th><th>Specs</th><th>Status</th><th>Node</th><th></th></tr></thead>
      <tbody>${vpsList.map((v) => `
        <tr>
          <td>${v.container_name}</td><td class="muted">${v.user_id}</td>
          <td>${v.ram} / ${v.cpu} cpu / ${v.storage}</td>
          <td>${v.suspended ? '<span class="badge suspended">Suspended</span>' : `<span class="badge ${v.status==='running'?'running':'stopped'}">${v.status}</span>`}</td>
          <td>${(nodes.find(n=>n.id===v.node_id)||{}).name || v.node_id}</td>
          <td class="row" style="gap:4px;flex-wrap:wrap;">
            ${v.suspended
              ? `<button class="btn small success" data-unsuspend="${v.id}">Unsuspend</button>`
              : `<button class="btn small secondary" data-suspend="${v.id}">Suspend</button>`}
            <button class="btn small secondary" data-renew="${v.id}">Renew</button>
            <button class="btn small danger" data-delete="${v.id}">Delete</button>
          </td>
        </tr>`).join('') || '<tr><td colspan="6" class="muted">No VPS yet</td></tr>'}
      </tbody>
    </table>
  `;
  document.getElementById('new-vps-btn').addEventListener('click', async () => {
    const user_id = prompt('User ID (client user_id) to create VPS for:');
    if (!user_id) return;
    const ram = parseInt(prompt('RAM (GB):', '2'), 10);
    const cpu = parseInt(prompt('CPU cores:', '1'), 10);
    const disk = parseInt(prompt('Disk (GB):', '10'), 10);
    await api('/api/admin/vps/create', { method: 'POST', body: JSON.stringify({ user_id, ram, cpu, disk }) });
    toast('VPS created'); navigate('vps');
  });
  root.querySelectorAll('button[data-suspend]').forEach((btn) => btn.addEventListener('click', async () => {
    const reason = prompt('Suspension reason:', 'Admin action') || 'Admin action';
    await api(`/api/admin/vps/${btn.dataset.suspend}/suspend`, { method: 'POST', body: JSON.stringify({ reason }) });
    navigate('vps');
  }));
  root.querySelectorAll('button[data-unsuspend]').forEach((btn) => btn.addEventListener('click', async () => {
    await api(`/api/admin/vps/${btn.dataset.unsuspend}/unsuspend`, { method: 'POST' });
    navigate('vps');
  }));
  root.querySelectorAll('button[data-renew]').forEach((btn) => btn.addEventListener('click', async () => {
    const days = parseInt(prompt('Extend by how many days?', '7'), 10) || 7;
    await api(`/api/admin/vps/${btn.dataset.renew}/renew`, { method: 'POST', body: JSON.stringify({ days }) });
    toast('VPS renewed'); navigate('vps');
  }));
  root.querySelectorAll('button[data-delete]').forEach((btn) => btn.addEventListener('click', async () => {
    if (!confirm('Delete this VPS permanently?')) return;
    const reason = prompt('Reason:', 'Admin deletion') || 'Admin deletion';
    await api(`/api/admin/vps/${btn.dataset.delete}`, { method: 'DELETE', body: JSON.stringify({ reason }) });
    toast('VPS deleted'); navigate('vps');
  }));
}

async function renderNodes(root) {
  const nodes = await api('/api/admin/nodes');
  root.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div class="row" style="gap:8px;">
        <input id="node-name" placeholder="Node name" />
        <input id="node-location" placeholder="Location" />
        <input id="node-capacity" placeholder="Capacity" type="number" />
        <button class="btn" id="add-node">Add Node</button>
      </div>
    </div>
    <table>
      <thead><tr><th>Name</th><th>Location</th><th>Capacity</th><th>Local</th><th></th></tr></thead>
      <tbody>${nodes.map((n) => `
        <tr><td>${n.name}</td><td>${n.location||''}</td><td>${n.total_vps}</td><td>${n.is_local?'Yes':'No'}</td>
        <td>${n.is_local?'':`<button class="btn small danger" data-del-node="${n.id}">Delete</button>`}</td></tr>
      `).join('')}</tbody>
    </table>
  `;
  document.getElementById('add-node').addEventListener('click', async () => {
    const name = document.getElementById('node-name').value.trim();
    const location = document.getElementById('node-location').value.trim();
    const total_vps = parseInt(document.getElementById('node-capacity').value, 10) || 10;
    if (!name) return;
    await api('/api/admin/nodes', { method: 'POST', body: JSON.stringify({ name, location, total_vps }) });
    navigate('nodes');
  });
  root.querySelectorAll('button[data-del-node]').forEach((btn) => btn.addEventListener('click', async () => {
    await api(`/api/admin/nodes/${btn.dataset.delNode}`, { method: 'DELETE' });
    navigate('nodes');
  }));
}

function planForm(prefix) {
  return `
    <div class="row" style="gap:8px;flex-wrap:wrap;">
      <input id="${prefix}-name" placeholder="Plan name" />
      <input id="${prefix}-ram" type="number" placeholder="RAM GB" />
      <input id="${prefix}-cpu" type="number" placeholder="CPU cores" />
      <input id="${prefix}-disk" type="number" placeholder="Disk GB" />
      ${prefix === 'dp' ? '<input id="dp-days" type="number" placeholder="Duration days" />' : ''}
      <input id="${prefix}-cost" type="number" placeholder="Cost (coins)" />
      <button class="btn" id="${prefix}-add">Add Plan</button>
    </div>`;
}

async function renderDeployPlans(root) {
  const plans = await api('/api/admin/plans/deploy');
  root.innerHTML = `<div class="card" style="margin-bottom:16px;">${planForm('dp')}</div>
    <table><thead><tr><th>Name</th><th>Specs</th><th>Days</th><th>Cost</th><th>Active</th><th></th></tr></thead>
    <tbody>${plans.map((p) => `<tr>
      <td>${p.icon} ${p.name}</td><td>${p.ram_gb}GB/${p.cpu_cores}cpu/${p.disk_gb}GB</td>
      <td>${p.duration_days}</td><td>${p.cost_coins}</td><td>${p.active?'Yes':'No'}</td>
      <td class="row" style="gap:4px;">
        <button class="btn small secondary" data-toggle-dp="${p.id}">${p.active?'Disable':'Enable'}</button>
        <button class="btn small danger" data-del-dp="${p.id}">Delete</button>
      </td></tr>`).join('') || '<tr><td colspan="6" class="muted">No plans yet</td></tr>'}</tbody></table>`;
  document.getElementById('dp-add').addEventListener('click', async () => {
    const name = document.getElementById('dp-name').value.trim();
    const ram_gb = parseInt(document.getElementById('dp-ram').value, 10);
    const cpu_cores = parseInt(document.getElementById('dp-cpu').value, 10);
    const disk_gb = parseInt(document.getElementById('dp-disk').value, 10);
    const duration_days = parseInt(document.getElementById('dp-days').value, 10);
    const cost_coins = parseInt(document.getElementById('dp-cost').value, 10);
    if (!name || !ram_gb || !cpu_cores || !disk_gb || !duration_days || !cost_coins) return toast('Fill all fields', 'error');
    await api('/api/admin/plans/deploy', { method: 'POST', body: JSON.stringify({ name, ram_gb, cpu_cores, disk_gb, duration_days, cost_coins }) });
    navigate('deployplans');
  });
  root.querySelectorAll('button[data-toggle-dp]').forEach((btn) => btn.addEventListener('click', async () => {
    const p = plans.find((x) => x.id == btn.dataset.toggleDp);
    await api(`/api/admin/plans/deploy/${p.id}`, { method: 'PUT', body: JSON.stringify({ active: p.active ? 0 : 1 }) });
    navigate('deployplans');
  }));
  root.querySelectorAll('button[data-del-dp]').forEach((btn) => btn.addEventListener('click', async () => {
    if (!confirm('Delete this plan?')) return;
    await api(`/api/admin/plans/deploy/${btn.dataset.delDp}`, { method: 'DELETE' });
    navigate('deployplans');
  }));
}

async function renderResourcePlans(root) {
  const plans = await api('/api/admin/plans/resource');
  root.innerHTML = `<div class="card" style="margin-bottom:16px;">${planForm('rp')}</div>
    <table><thead><tr><th>Name</th><th>Specs</th><th>Cost</th><th>Active</th><th></th></tr></thead>
    <tbody>${plans.map((p) => `<tr>
      <td>${p.icon} ${p.name}</td><td>${p.ram_gb}GB/${p.cpu_cores}cpu/${p.disk_gb}GB</td>
      <td>${p.cost_coins}</td><td>${p.active?'Yes':'No'}</td>
      <td class="row" style="gap:4px;">
        <button class="btn small secondary" data-toggle-rp="${p.id}">${p.active?'Disable':'Enable'}</button>
        <button class="btn small danger" data-del-rp="${p.id}">Delete</button>
      </td></tr>`).join('') || '<tr><td colspan="5" class="muted">No plans yet</td></tr>'}</tbody></table>`;
  document.getElementById('rp-add').addEventListener('click', async () => {
    const name = document.getElementById('rp-name').value.trim();
    const ram_gb = parseInt(document.getElementById('rp-ram').value, 10);
    const cpu_cores = parseInt(document.getElementById('rp-cpu').value, 10);
    const disk_gb = parseInt(document.getElementById('rp-disk').value, 10);
    const cost_coins = parseInt(document.getElementById('rp-cost').value, 10);
    if (!name || !ram_gb || !cpu_cores || !disk_gb || !cost_coins) return toast('Fill all fields', 'error');
    await api('/api/admin/plans/resource', { method: 'POST', body: JSON.stringify({ name, ram_gb, cpu_cores, disk_gb, cost_coins }) });
    navigate('resourceplans');
  });
  root.querySelectorAll('button[data-toggle-rp]').forEach((btn) => btn.addEventListener('click', async () => {
    const p = plans.find((x) => x.id == btn.dataset.toggleRp);
    await api(`/api/admin/plans/resource/${p.id}`, { method: 'PUT', body: JSON.stringify({ active: p.active ? 0 : 1 }) });
    navigate('resourceplans');
  }));
  root.querySelectorAll('button[data-del-rp]').forEach((btn) => btn.addEventListener('click', async () => {
    if (!confirm('Delete this plan?')) return;
    await api(`/api/admin/plans/resource/${btn.dataset.delRp}`, { method: 'DELETE' });
    navigate('resourceplans');
  }));
}

async function renderCoupons(root) {
  const coupons = await api('/api/admin/coupons');
  root.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div class="row" style="gap:8px;flex-wrap:wrap;">
        <input id="cp-code" placeholder="Code" />
        <input id="cp-coins" type="number" placeholder="Coins" />
        <input id="cp-maxuses" type="number" placeholder="Max uses (blank=unlimited)" />
        <input id="cp-expires" type="number" placeholder="Expires in days (blank=never)" />
        <button class="btn" id="cp-add">Create Coupon</button>
      </div>
    </div>
    <table><thead><tr><th>Code</th><th>Coins</th><th>Uses</th><th>Active</th><th>Expires</th><th></th></tr></thead>
    <tbody>${coupons.map((c) => `<tr>
      <td>${c.code}</td><td>${c.coins}</td><td>${c.uses}${c.max_uses?'/'+c.max_uses:''}</td>
      <td>${c.active?'Yes':'No'}</td><td class="muted">${c.expires_at ? new Date(c.expires_at).toLocaleDateString() : 'Never'}</td>
      <td class="row" style="gap:4px;">
        <button class="btn small secondary" data-toggle-cp="${c.id}">${c.active?'Disable':'Enable'}</button>
        <button class="btn small danger" data-del-cp="${c.id}">Delete</button>
      </td></tr>`).join('') || '<tr><td colspan="6" class="muted">No coupons yet</td></tr>'}</tbody></table>
  `;
  document.getElementById('cp-add').addEventListener('click', async () => {
    const code = document.getElementById('cp-code').value.trim();
    const coins = parseInt(document.getElementById('cp-coins').value, 10);
    const max_uses = parseInt(document.getElementById('cp-maxuses').value, 10) || null;
    const expires_in_days = parseInt(document.getElementById('cp-expires').value, 10) || null;
    if (!code || !coins) return toast('Code and coins are required', 'error');
    await api('/api/admin/coupons', { method: 'POST', body: JSON.stringify({ code, coins, max_uses, expires_in_days }) });
    navigate('coupons');
  });
  root.querySelectorAll('button[data-toggle-cp]').forEach((btn) => btn.addEventListener('click', async () => {
    const c = coupons.find((x) => x.id == btn.dataset.toggleCp);
    await api(`/api/admin/coupons/${c.id}/toggle`, { method: 'POST', body: JSON.stringify({ active: c.active ? 0 : 1 }) });
    navigate('coupons');
  }));
  root.querySelectorAll('button[data-del-cp]').forEach((btn) => btn.addEventListener('click', async () => {
    await api(`/api/admin/coupons/${btn.dataset.delCp}`, { method: 'DELETE' });
    navigate('coupons');
  }));
}

async function renderSecurity(root) {
  const logs = await api('/api/admin/security-logs');
  root.innerHTML = `
    <table><thead><tr><th>User</th><th>Type</th><th>Description</th><th>When</th></tr></thead>
    <tbody>${logs.map((l) => `<tr>
      <td class="muted">${l.user_id || '—'}</td><td>${l.activity_type}</td><td>${l.description || ''}</td>
      <td class="muted">${new Date(l.created_at).toLocaleString()}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">No events logged</td></tr>'}
    </tbody></table>`;
}

async function renderSettings(root) {
  const settings = await api('/api/admin/settings');
  root.innerHTML = `
    <div class="card" style="max-width:400px;">
      <label>CPU Threshold (%)</label>
      <input id="set-cpu" value="${settings.cpu_threshold || 90}" />
      <label>RAM Threshold (%)</label>
      <input id="set-ram" value="${settings.ram_threshold || 90}" />
      <label>Renew Cost / Day (coins)</label>
      <input id="set-renew" value="${settings.renew_cost_per_day || 10}" />
      <button class="btn" id="save-settings" style="margin-top:14px;">Save Settings</button>
    </div>`;
  document.getElementById('save-settings').addEventListener('click', async () => {
    await api('/api/admin/settings', { method: 'POST', body: JSON.stringify({
      cpu_threshold: document.getElementById('set-cpu').value,
      ram_threshold: document.getElementById('set-ram').value,
      renew_cost_per_day: document.getElementById('set-renew').value,
    }) });
    toast('Settings saved');
  });
}

async function renderAdmins(root) {
  const admins = await api('/api/admin/admins');
  root.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div class="row" style="gap:8px;">
        <input id="new-admin-id" placeholder="User ID to promote" />
        <button class="btn" id="add-admin">Add Admin</button>
      </div>
    </div>
    <table><thead><tr><th>User ID</th><th></th></tr></thead>
    <tbody>${admins.map((a) => `<tr><td>${a.user_id}</td><td><button class="btn small danger" data-del-admin="${a.user_id}">Remove</button></td></tr>`).join('')}</tbody></table>
  `;
  document.getElementById('add-admin').addEventListener('click', async () => {
    const user_id = document.getElementById('new-admin-id').value.trim();
    if (!user_id) return;
    await api('/api/admin/admins', { method: 'POST', body: JSON.stringify({ user_id }) });
    navigate('admins');
  });
  root.querySelectorAll('button[data-del-admin]').forEach((btn) => btn.addEventListener('click', async () => {
    await api(`/api/admin/admins/${btn.dataset.delAdmin}`, { method: 'DELETE' });
    navigate('admins');
  }));
}

checkAuth();
