// Wraps the system `lxc`/`incus` binary the same way main.py's execute_lxc() did.
// On a machine without lxc installed, calls will fail gracefully and the API
// will report the error back to the caller instead of crashing the server.
const { exec } = require('child_process');

const LXC_BIN = process.env.LXC_BIN || 'lxc'; // set to "incus" if using Incus instead of LXD

function run(cmd, timeoutMs = 120000) {
  return new Promise((resolve) => {
    exec(cmd, { timeout: timeoutMs, maxBuffer: 10 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) {
        resolve({ ok: false, stdout: stdout || '', stderr: stderr || err.message, code: err.code });
      } else {
        resolve({ ok: true, stdout: stdout || '', stderr: stderr || '', code: 0 });
      }
    });
  });
}

async function executeLxc(containerName, args, timeoutMs = 120000) {
  const cmd = `${LXC_BIN} ${args.replace('{name}', JSON.stringify(containerName))}`;
  return run(cmd, timeoutMs);
}

const lxc = {
  launch: (name, image, opts = {}) =>
    run(`${LXC_BIN} launch ${image} ${name} ${opts.profile ? `-p ${opts.profile}` : ''}`),
  start: (name) => run(`${LXC_BIN} start ${name}`),
  stop: (name) => run(`${LXC_BIN} stop ${name} --force`),
  restart: (name) => run(`${LXC_BIN} restart ${name} --force`),
  delete: (name) => run(`${LXC_BIN} delete ${name} --force`),
  info: (name) => run(`${LXC_BIN} info ${name}`),
  list: () => run(`${LXC_BIN} list --format json`),
  exec: (name, command) => run(`${LXC_BIN} exec ${name} -- bash -c ${JSON.stringify(command)}`),
  setConfig: (name, key, value) => run(`${LXC_BIN} config set ${name} ${key} ${value}`),
  setLimits: (name, { cpu, ram, disk }) => {
    const cmds = [];
    if (cpu) cmds.push(`${LXC_BIN} config set ${name} limits.cpu ${cpu}`);
    if (ram) cmds.push(`${LXC_BIN} config set ${name} limits.memory ${ram}GB`);
    if (disk) cmds.push(`${LXC_BIN} config device set ${name} root size=${disk}GB`);
    return run(cmds.join(' && '));
  },
  snapshot: (name, snap) => run(`${LXC_BIN} snapshot ${name} ${snap}`),
  listSnapshots: (name) => run(`${LXC_BIN} info ${name}`),
  restoreSnapshot: (name, snap) => run(`${LXC_BIN} restore ${name} ${snap}`),
  clone: (name, newName) => run(`${LXC_BIN} copy ${name} ${newName}`),
  move: (name, target) => run(`${LXC_BIN} move ${name} ${target}`),
};

module.exports = { lxc, run, executeLxc };
