const api = async (url, opts = {}) => {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    ...opts,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
};

function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

let me = null;
let mode = 'login';

const loginView = document.getElementById('login-view');
const appView = document.getElementById('app-view');

async function checkAuth() {
  try {
    me = await api('/api/auth/me');
    showApp();
  } catch {
    showLogin();
  }
}

function showLogin() {
  loginView.classList.remove('hidden');
  appView.classList.add('hidden');
}

function showApp() {
  loginView.classList.add('hidden');
  appView.classList.remove('hidden');
  document.getElementById('chip-username').textContent = me.username;
  navigate('overview');
  refreshBalance();
}

document.getElementById('auth-switch').addEventListener('click', () => {
  mode = mode === 'login' ? 'register' : 'login';
  document.getElementById('auth-title').textContent = mode === 'login' ? 'Sign in' : 'Create account';
  document.getElementById('auth-submit').textContent = mode === 'login' ? 'Sign in' : 'Register';
  document.getElementById('auth-switch').textContent = mode === 'login' ? "Don't have an account? Register" : 'Already have an account? Sign in';
  document.getElementById('register-extra').classList.toggle('hidden', mode === 'login');
});

document.getElementById('auth-submit').addEventListener('click', async () => {
  const username = document.getElementById('auth-username').value.trim();
  const password = document.getElementById('auth-password').value;
  const email = document.getElementById('auth-email').value.trim();
  const errEl = document.getElementById('auth-error');
  errEl.textContent = '';
  try {
    if (mode === 'login') {
      me = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
    } else {
      me = await api('/api/auth/register', { method: 'POST', body: JSON.stringify({ username, password, email }) });
    }
    showApp();
  } catch (e) {
    errEl.textContent = e.message;
  }
});

document.getElementById('logout-btn').addEventListener('click', async () => {
  await api('/api/auth/logout', { method: 'POST' });
  location.reload();
});

document.querySelectorAll('.nav-item[data-view]').forEach((el) => {
  el.addEventListener('click', () => navigate(el.dataset.view));
});

function setActiveNav(view) {
  document.querySelectorAll('.nav-item[data-view]').forEach((el) => {
    el.classList.toggle('active', el.dataset.view === view);
  });
}

async function refreshBalance() {
  try {
    const coins = await api('/api/client/coins');
    document.getElementById('chip-balance').textContent = `${coins.balance} coins`;
  } catch {}
}

const titles = {
  overview: 'Overview',
  myvps: 'My VPS',
  deploy: 'Deploy New VPS',
  ports: 'Port Forwards',
  coins: 'Coins & Rewards',
  redeem: 'Redeem Coupon',
};

async function navigate(view) {
  setActiveNav(view);
  document.getElementById('view-title').textContent = titles[view] || view;
  const root = document.getElementById('view-root');
  root.innerHTML = '<div class="muted">Loading…</div>';
  try {
    if (view === 'overview') await renderOverview(root);
    else if (view === 'myvps') await renderMyVps(root);
    else if (view === 'deploy') await renderDeploy(root);
    else if (view === 'ports') await renderPorts(root);
    else if (view === 'coins') await renderCoins(root);
    else if (view === 'redeem') await renderRedeem(root);
  } catch (e) {
    root.innerHTML = `<div class="card">Error: ${e.message}</div>`;
  }
}

async function renderOverview(root) {
  const [vpsList, coins] = await Promise.all([api('/api/client/vps'), api('/api/client/coins')]);
  const running = vpsList.filter((v) => v.status === 'running').length;
  root.innerHTML = `
    <div class="stat-grid">
      <div class="stat"><div class="label">Total VPS</div><div class="value">${vpsList.length}</div></div>
      <div class="stat"><div class="label">Running</div><div class="value">${running}</div></div>
      <div class="stat"><div class="label">Coin Balance</div><div class="value">${coins.balance}</div></div>
      <div class="stat"><div class="label">Total Earned</div><div class="value">${coins.total_earned}</div></div>
    </div>
    <div class="card">
      <h3 style="margin-top:0">Welcome back, ${me.username} 👋</h3>
      <p class="muted">Use the sidebar to manage your VPS instances, deploy new ones, manage port forwards, and earn coins.</p>
    </div>
  `;
}

function statusBadge(v) {
  if (v.suspended) return `<span class="badge suspended">Suspended</span>`;
  const cls = v.status === 'running' ? 'running' : v.status === 'error' ? 'error' : 'stopped';
  return `<span class="badge ${cls}">${v.status}</span>`;
}

async function renderMyVps(root) {
  const vpsList = await api('/api/client/vps');
  if (!vpsList.length) {
    root.innerHTML = `<div class="card">You don't have any VPS yet. Go to <b>Deploy New</b> to create one.</div>`;
    return;
  }
  root.innerHTML = `<div class="grid">${vpsList.map(vpsCard).join('')}</div><div id="console-area"></div>`;
  vpsList.forEach((v) => bindVpsCard(v));
}

function vpsCard(v) {
  return `
  <div class="card" id="vps-${v.id}">
    <div class="row between">
      <b>${v.container_name}</b>
      ${statusBadge(v)}
    </div>
    <p class="muted">RAM ${v.ram} · CPU ${v.cpu} · Disk ${v.storage} · ${v.os_version}</p>
    ${v.expiration ? `<p class="muted">Expires: ${new Date(v.expiration.expires_at).toLocaleString()}</p>` : ''}
    <div class="row" style="margin-top:10px;flex-wrap:wrap;gap:6px;">
      <button class="btn small" data-action="start" data-id="${v.id}">Start</button>
      <button class="btn small secondary" data-action="stop" data-id="${v.id}">Stop</button>
      <button class="btn small secondary" data-action="restart" data-id="${v.id}">Restart</button>
      <button class="btn small secondary" data-action="snapshot" data-id="${v.id}">Snapshot</button>
      <button class="btn small secondary" data-action="renew" data-id="${v.id}">Renew</button>
      <button class="btn small secondary" data-action="exec" data-id="${v.id}">Exec</button>
    </div>
  </div>`;
}

function bindVpsCard(v) {
  const card = document.getElementById(`vps-${v.id}`);
  card.querySelectorAll('button[data-action]').forEach((btn) => {
    btn.addEventListener('click', () => handleVpsAction(v.id, btn.dataset.action));
  });
}

async function handleVpsAction(id, action) {
  try {
    if (action === 'start') { await api(`/api/client/vps/${id}/start`, { method: 'POST' }); toast('VPS starting…'); }
    else if (action === 'stop') { await api(`/api/client/vps/${id}/stop`, { method: 'POST' }); toast('VPS stopped'); }
    else if (action === 'restart') { await api(`/api/client/vps/${id}/restart`, { method: 'POST' }); toast('VPS restarting…'); }
    else if (action === 'snapshot') {
      const name = prompt('Snapshot name:', 'snap0') || 'snap0';
      await api(`/api/client/vps/${id}/snapshot`, { method: 'POST', body: JSON.stringify({ name }) });
      toast('Snapshot created');
    } else if (action === 'renew') {
      const days = parseInt(prompt('Renew for how many days?', '1'), 10) || 1;
      const r = await api(`/api/client/vps/${id}/renew`, { method: 'POST', body: JSON.stringify({ days }) });
      toast(`Renewed until ${new Date(r.expires_at).toLocaleString()}`);
      refreshBalance();
    } else if (action === 'exec') {
      const command = prompt('Command to run inside the VPS:');
      if (!command) return;
      const r = await api(`/api/client/vps/${id}/exec`, { method: 'POST', body: JSON.stringify({ command }) });
      document.getElementById('console-area').innerHTML = `<div class="card"><pre class="console">${(r.stdout || r.stderr || '').replace(/</g, '&lt;')}</pre></div>`;
    }
    navigate('myvps');
  } catch (e) {
    toast(e.message, 'error');
  }
}

async function renderDeploy(root) {
  const plans = await api('/api/client/plans/deploy');
  if (!plans.length) {
    root.innerHTML = `<div class="card">No deploy plans are currently available. Check back later.</div>`;
    return;
  }
  root.innerHTML = `<div class="grid">${plans.map((p) => `
    <div class="card">
      <div class="row between"><b>${p.icon} ${p.name}</b><span class="muted">${p.cost_coins} coins</span></div>
      <p class="muted">${p.description || ''}</p>
      <p class="muted">RAM ${p.ram_gb}GB · CPU ${p.cpu_cores} · Disk ${p.disk_gb}GB · ${p.duration_days} days</p>
      <button class="btn small" data-plan="${p.id}">Deploy</button>
    </div>
  `).join('')}</div>`;
  root.querySelectorAll('button[data-plan]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await api('/api/client/vps/deploy', { method: 'POST', body: JSON.stringify({ plan_id: btn.dataset.plan }) });
        toast('VPS deployed! Check "My VPS".');
        refreshBalance();
        navigate('myvps');
      } catch (e) { toast(e.message, 'error'); }
    });
  });
}

async function renderPorts(root) {
  const { forwards, allocated, used } = await api('/api/client/ports');
  const vpsList = await api('/api/client/vps');
  root.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <p class="muted">Allocated: ${allocated} · Used: ${used}</p>
      <label>VPS</label>
      <select id="pf-vps">${vpsList.map((v) => `<option value="${v.id}">${v.container_name}</option>`).join('')}</select>
      <label>VPS Port</label>
      <input id="pf-port" type="number" placeholder="e.g. 8080" />
      <button class="btn" id="pf-add" style="margin-top:12px;">Add Forward</button>
    </div>
    <table>
      <thead><tr><th>Container</th><th>VPS Port</th><th>Host Port</th><th></th></tr></thead>
      <tbody>${forwards.map((f) => `
        <tr>
          <td>${f.vps_container}</td><td>${f.vps_port}</td><td>${f.host_port}</td>
          <td><button class="btn small danger" data-del="${f.id}">Remove</button></td>
        </tr>`).join('') || '<tr><td colspan="4" class="muted">No port forwards yet</td></tr>'}
      </tbody>
    </table>
  `;
  document.getElementById('pf-add').addEventListener('click', async () => {
    const vps_id = document.getElementById('pf-vps').value;
    const vps_port = parseInt(document.getElementById('pf-port').value, 10);
    if (!vps_port) return toast('Enter a valid port', 'error');
    try {
      await api('/api/client/ports', { method: 'POST', body: JSON.stringify({ vps_id, vps_port }) });
      toast('Port forward added');
      navigate('ports');
    } catch (e) { toast(e.message, 'error'); }
  });
  root.querySelectorAll('button[data-del]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      await api(`/api/client/ports/${btn.dataset.del}`, { method: 'DELETE' });
      navigate('ports');
    });
  });
}

async function renderCoins(root) {
  const [coins, txns, lb] = await Promise.all([
    api('/api/client/coins'), api('/api/client/coins/transactions'), api('/api/client/coins/leaderboard'),
  ]);
  root.innerHTML = `
    <div class="stat-grid">
      <div class="stat"><div class="label">Balance</div><div class="value">${coins.balance}</div></div>
      <div class="stat"><div class="label">Total Earned</div><div class="value">${coins.total_earned}</div></div>
      <div class="stat"><div class="label">Total Spent</div><div class="value">${coins.total_spent}</div></div>
    </div>
    <div class="card" style="margin-bottom:16px;">
      <button class="btn" id="claim-daily">Claim Daily Reward</button>
    </div>
    <div class="grid">
      <div class="card">
        <h3 style="margin-top:0;">Recent Transactions</h3>
        ${txns.map((t) => `<div class="row between" style="padding:6px 0;border-bottom:1px solid var(--border);">
          <span>${t.description || t.type}</span><span style="color:${t.amount >= 0 ? 'var(--success)' : 'var(--danger)'}">${t.amount >= 0 ? '+' : ''}${t.amount}</span>
        </div>`).join('') || '<p class="muted">No transactions yet</p>'}
      </div>
      <div class="card">
        <h3 style="margin-top:0;">Leaderboard</h3>
        ${lb.map((u, i) => `<div class="row between" style="padding:6px 0;border-bottom:1px solid var(--border);">
          <span>#${i + 1} ${u.user_id === me.userId ? '<b>You</b>' : u.user_id.slice(0, 8)}</span><span>${u.balance}</span>
        </div>`).join('')}
      </div>
    </div>
  `;
  document.getElementById('claim-daily').addEventListener('click', async () => {
    try {
      const r = await api('/api/client/coins/daily', { method: 'POST' });
      toast(`+${r.reward} coins claimed!`);
      refreshBalance();
      navigate('coins');
    } catch (e) { toast(e.message, 'error'); }
  });
}

async function renderRedeem(root) {
  root.innerHTML = `
    <div class="card" style="max-width:360px;">
      <label>Coupon Code</label>
      <input id="redeem-code" placeholder="e.g. WELCOME50" />
      <button class="btn" id="redeem-btn" style="margin-top:12px;">Redeem</button>
    </div>
  `;
  document.getElementById('redeem-btn').addEventListener('click', async () => {
    const code = document.getElementById('redeem-code').value.trim();
    if (!code) return;
    try {
      const r = await api('/api/client/coins/redeem', { method: 'POST', body: JSON.stringify({ code }) });
      toast(`+${r.coins} coins added!`);
      refreshBalance();
    } catch (e) { toast(e.message, 'error'); }
  });
}

checkAuth();
