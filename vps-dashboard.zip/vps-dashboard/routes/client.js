const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { lxc } = require('../lxc');
const { requireLogin } = require('../middleware/auth');

const router = express.Router();
router.use(requireLogin);

function getUserCoins(userId) {
  let row = db.prepare('SELECT * FROM user_coins WHERE user_id = ?').get(userId);
  if (!row) {
    db.prepare(`INSERT INTO user_coins (user_id, balance, total_earned, total_spent, created_at)
                VALUES (?, 0, 0, 0, ?)`).run(userId, new Date().toISOString());
    row = db.prepare('SELECT * FROM user_coins WHERE user_id = ?').get(userId);
  }
  return row;
}

function addCoins(userId, amount, type, description) {
  getUserCoins(userId);
  db.prepare(`UPDATE user_coins SET balance = balance + ?, total_earned = total_earned + ? WHERE user_id = ?`)
    .run(amount, amount > 0 ? amount : 0, userId);
  db.prepare(`INSERT INTO coin_transactions (user_id, amount, type, description, created_at)
              VALUES (?, ?, ?, ?, ?)`).run(userId, amount, type, description || null, new Date().toISOString());
  return getUserCoins(userId).balance;
}

// ---------- VPS ----------

router.get('/vps', (req, res) => {
  const rows = db.prepare(`SELECT * FROM vps WHERE user_id = ? OR shared_with LIKE ? ORDER BY id`)
    .all(req.session.userId, `%${req.session.userId}%`);
  const expirations = db.prepare('SELECT * FROM vps_expiration').all();
  const expMap = Object.fromEntries(expirations.map((e) => [e.vps_id, e]));
  res.json(rows.map((v) => ({ ...v, expiration: expMap[v.id] || null })));
});

router.get('/vps/:id', (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const owns = v.user_id === req.session.userId || (v.shared_with || '').includes(req.session.userId);
  if (!owns) return res.status(403).json({ error: 'Not your VPS' });
  res.json(v);
});

router.post('/vps/deploy', (req, res) => {
  const { plan_id } = req.body || {};
  const plan = db.prepare('SELECT * FROM deploy_plans WHERE id = ? AND active = 1').get(plan_id);
  if (!plan) return res.status(404).json({ error: 'Deploy plan not found or inactive' });

  const coins = getUserCoins(req.session.userId);
  if (coins.balance < plan.cost_coins) return res.status(400).json({ error: 'Not enough coins' });

  const containerName = `vps-${req.session.userId.slice(0, 6)}-${crypto.randomBytes(3).toString('hex')}`;
  const localNode = db.prepare('SELECT * FROM nodes WHERE is_local = 1').get();

  db.prepare(`INSERT INTO vps (user_id, node_id, container_name, ram, cpu, storage, config, os_version, status, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'stopped', ?)`)
    .run(req.session.userId, localNode.id, containerName, `${plan.ram_gb}GB`, `${plan.cpu_cores}`,
         `${plan.disk_gb}GB`, JSON.stringify({ plan: plan.name }), 'ubuntu:22.04', new Date().toISOString());

  const vpsRow = db.prepare('SELECT * FROM vps WHERE container_name = ?').get(containerName);

  const expiresAt = new Date(Date.now() + plan.duration_days * 86400000).toISOString();
  db.prepare(`INSERT INTO vps_expiration (vps_id, expires_at, duration_days, auto_renew) VALUES (?, ?, ?, 0)`)
    .run(vpsRow.id, expiresAt, plan.duration_days);

  addCoins(req.session.userId, -plan.cost_coins, 'purchase', `Deployed VPS via plan "${plan.name}"`);

  // Fire-and-forget container creation; status is reported back via /vps/:id
  lxc.launch(containerName, plan.name.toLowerCase().includes('debian') ? 'images:debian/12' : 'ubuntu:22.04')
    .then((r) => {
      db.prepare('UPDATE vps SET status = ? WHERE id = ?').run(r.ok ? 'running' : 'error', vpsRow.id);
      if (r.ok) lxc.setLimits(containerName, { cpu: plan.cpu_cores, ram: plan.ram_gb, disk: plan.disk_gb });
    });

  res.json({ ok: true, vps: vpsRow });
});

function ownedVps(req, id) {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(id);
  if (!v) return null;
  const owns = v.user_id === req.session.userId || (v.shared_with || '').includes(req.session.userId);
  return owns ? v : null;
}

router.post('/vps/:id/start', async (req, res) => {
  const v = ownedVps(req, req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  if (v.suspended) return res.status(403).json({ error: 'VPS is suspended' });
  const r = await lxc.start(v.container_name);
  if (r.ok) db.prepare('UPDATE vps SET status = ? WHERE id = ?').run('running', v.id);
  res.json({ ok: r.ok, output: r.ok ? r.stdout : r.stderr });
});

router.post('/vps/:id/stop', async (req, res) => {
  const v = ownedVps(req, req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const r = await lxc.stop(v.container_name);
  if (r.ok) db.prepare('UPDATE vps SET status = ? WHERE id = ?').run('stopped', v.id);
  res.json({ ok: r.ok, output: r.ok ? r.stdout : r.stderr });
});

router.post('/vps/:id/restart', async (req, res) => {
  const v = ownedVps(req, req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  if (v.suspended) return res.status(403).json({ error: 'VPS is suspended' });
  const r = await lxc.restart(v.container_name);
  res.json({ ok: r.ok, output: r.ok ? r.stdout : r.stderr });
});

router.post('/vps/:id/exec', async (req, res) => {
  const v = ownedVps(req, req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  if (v.suspended) return res.status(403).json({ error: 'VPS is suspended' });
  const { command } = req.body || {};
  if (!command) return res.status(400).json({ error: 'command is required' });
  const r = await lxc.exec(v.container_name, command);
  res.json({ ok: r.ok, stdout: r.stdout, stderr: r.stderr });
});

router.post('/vps/:id/snapshot', async (req, res) => {
  const v = ownedVps(req, req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const { name } = req.body || {};
  const r = await lxc.snapshot(v.container_name, name || 'snap0');
  res.json({ ok: r.ok, output: r.ok ? r.stdout : r.stderr });
});

router.post('/vps/:id/upgrade', (req, res) => {
  const v = ownedVps(req, req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const { plan_id } = req.body || {};
  const plan = db.prepare('SELECT * FROM resource_plans WHERE id = ? AND active = 1').get(plan_id);
  if (!plan) return res.status(404).json({ error: 'Resource plan not found' });
  const coins = getUserCoins(req.session.userId);
  if (coins.balance < plan.cost_coins) return res.status(400).json({ error: 'Not enough coins' });

  addCoins(req.session.userId, -plan.cost_coins, 'upgrade', `Upgraded VPS #${v.id} via plan "${plan.name}"`);
  db.prepare('UPDATE vps SET ram = ?, cpu = ?, storage = ? WHERE id = ?')
    .run(`${plan.ram_gb}GB`, `${plan.cpu_cores}`, `${plan.disk_gb}GB`, v.id);
  lxc.setLimits(v.container_name, { cpu: plan.cpu_cores, ram: plan.ram_gb, disk: plan.disk_gb });
  res.json({ ok: true });
});

router.post('/vps/:id/renew', (req, res) => {
  const v = ownedVps(req, req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const { days } = req.body || {};
  const d = parseInt(days, 10) || 1;
  const costPerDay = parseInt(db.prepare("SELECT value FROM settings WHERE key='renew_cost_per_day'").get()?.value || '10', 10);
  const cost = costPerDay * d;
  const coins = getUserCoins(req.session.userId);
  if (coins.balance < cost) return res.status(400).json({ error: 'Not enough coins' });

  addCoins(req.session.userId, -cost, 'renew', `Renewed VPS #${v.id} for ${d} day(s)`);
  const exp = db.prepare('SELECT * FROM vps_expiration WHERE vps_id = ?').get(v.id);
  const base = exp && new Date(exp.expires_at) > new Date() ? new Date(exp.expires_at) : new Date();
  const newExpiry = new Date(base.getTime() + d * 86400000).toISOString();
  if (exp) {
    db.prepare('UPDATE vps_expiration SET expires_at = ? WHERE vps_id = ?').run(newExpiry, v.id);
  } else {
    db.prepare('INSERT INTO vps_expiration (vps_id, expires_at, duration_days, auto_renew) VALUES (?, ?, ?, 0)')
      .run(v.id, newExpiry, d);
  }
  res.json({ ok: true, expires_at: newExpiry });
});

router.post('/vps/:id/share', (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v || v.user_id !== req.session.userId) return res.status(404).json({ error: 'VPS not found' });
  const { user_id } = req.body || {};
  const shared = JSON.parse(v.shared_with || '[]');
  if (!shared.includes(user_id)) shared.push(user_id);
  db.prepare('UPDATE vps SET shared_with = ? WHERE id = ?').run(JSON.stringify(shared), v.id);
  res.json({ ok: true, shared_with: shared });
});

// ---------- Port forwards ----------

router.get('/ports', (req, res) => {
  const rows = db.prepare('SELECT * FROM port_forwards WHERE user_id = ?').all(req.session.userId);
  const alloc = db.prepare('SELECT * FROM port_allocations WHERE user_id = ?').get(req.session.userId);
  res.json({ forwards: rows, allocated: alloc?.allocated_ports || 0, used: rows.length });
});

router.post('/ports', (req, res) => {
  const { vps_id, vps_port } = req.body || {};
  const v = ownedVps(req, vps_id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });

  const alloc = db.prepare('SELECT * FROM port_allocations WHERE user_id = ?').get(req.session.userId);
  const used = db.prepare('SELECT COUNT(*) c FROM port_forwards WHERE user_id = ?').get(req.session.userId).c;
  if (used >= (alloc?.allocated_ports || 0)) return res.status(403).json({ error: 'No available port allocations' });

  const maxPort = db.prepare('SELECT MAX(host_port) m FROM port_forwards').get().m || 20000;
  const hostPort = Math.max(maxPort + 1, 20000);
  db.prepare(`INSERT INTO port_forwards (user_id, vps_container, vps_port, host_port, created_at)
              VALUES (?, ?, ?, ?, ?)`).run(req.session.userId, v.container_name, vps_port, hostPort, new Date().toISOString());
  res.json({ ok: true, host_port: hostPort });
});

router.delete('/ports/:id', (req, res) => {
  const fwd = db.prepare('SELECT * FROM port_forwards WHERE id = ? AND user_id = ?').get(req.params.id, req.session.userId);
  if (!fwd) return res.status(404).json({ error: 'Forward not found' });
  db.prepare('DELETE FROM port_forwards WHERE id = ?').run(fwd.id);
  res.json({ ok: true });
});

// ---------- Coins / economy ----------

router.get('/coins', (req, res) => res.json(getUserCoins(req.session.userId)));

router.post('/coins/daily', (req, res) => {
  const coins = getUserCoins(req.session.userId);
  const now = new Date();
  if (coins.last_daily) {
    const last = new Date(coins.last_daily);
    if (now - last < 20 * 60 * 60 * 1000) {
      return res.status(400).json({ error: 'Daily reward already claimed. Try again later.' });
    }
  }
  const reward = 100;
  db.prepare('UPDATE user_coins SET last_daily = ? WHERE user_id = ?').run(now.toISOString(), req.session.userId);
  const balance = addCoins(req.session.userId, reward, 'daily', 'Daily reward');
  res.json({ ok: true, reward, balance });
});

router.get('/coins/leaderboard', (req, res) => {
  const rows = db.prepare('SELECT user_id, balance FROM user_coins ORDER BY balance DESC LIMIT 10').all();
  res.json(rows);
});

router.get('/coins/transactions', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit, 10) || 10, 100);
  const rows = db.prepare('SELECT * FROM coin_transactions WHERE user_id = ? ORDER BY id DESC LIMIT ?')
    .all(req.session.userId, limit);
  res.json(rows);
});

router.post('/coins/redeem', (req, res) => {
  const { code } = req.body || {};
  const coupon = db.prepare('SELECT * FROM coupons WHERE code = ? AND active = 1').get(code);
  if (!coupon) return res.status(404).json({ error: 'Invalid or inactive coupon' });
  if (coupon.expires_at && new Date(coupon.expires_at) < new Date()) return res.status(400).json({ error: 'Coupon expired' });
  if (coupon.max_uses && coupon.uses >= coupon.max_uses) return res.status(400).json({ error: 'Coupon usage limit reached' });
  const already = db.prepare('SELECT 1 FROM coupon_redemptions WHERE coupon_id = ? AND user_id = ?')
    .get(coupon.id, req.session.userId);
  if (already) return res.status(400).json({ error: 'You already redeemed this coupon' });

  db.prepare('INSERT INTO coupon_redemptions (coupon_id, user_id, redeemed_at) VALUES (?, ?, ?)')
    .run(coupon.id, req.session.userId, new Date().toISOString());
  db.prepare('UPDATE coupons SET uses = uses + 1 WHERE id = ?').run(coupon.id);
  const balance = addCoins(req.session.userId, coupon.coins, 'coupon', `Redeemed coupon "${coupon.code}"`);
  res.json({ ok: true, coins: coupon.coins, balance });
});

// ---------- Plans ----------

router.get('/plans/deploy', (req, res) => {
  res.json(db.prepare('SELECT * FROM deploy_plans WHERE active = 1 ORDER BY cost_coins').all());
});

router.get('/plans/resource', (req, res) => {
  res.json(db.prepare('SELECT * FROM resource_plans WHERE active = 1 ORDER BY cost_coins').all());
});

module.exports = router;
