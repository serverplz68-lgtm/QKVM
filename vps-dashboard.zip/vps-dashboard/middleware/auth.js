const db = require('../db');

function requireLogin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
  next();
}

function isAdminId(userId) {
  if (!userId) return false;
  const row = db.prepare('SELECT 1 FROM admins WHERE user_id = ?').get(userId);
  return !!row;
}

function requireAdmin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
  if (!isAdminId(req.session.userId)) return res.status(403).json({ error: 'Admin privileges required' });
  next();
}

function isMainAdmin(userId) {
  return userId === (process.env.MAIN_ADMIN_ID || 'admin');
}

function requireMainAdmin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
  if (!isMainAdmin(req.session.userId)) return res.status(403).json({ error: 'Main admin privileges required' });
  next();
}

module.exports = { requireLogin, requireAdmin, requireMainAdmin, isAdminId, isMainAdmin };
