# VPS Dashboard (Node.js)

A two-part web dashboard converted from the original Discord bot (`main.py`), built with Express and SQLite.

- **Client portal** — `/client` — end users manage their own VPS, deploy new ones from plans, manage port forwards, earn/spend coins, redeem coupons.
- **Admin portal** — `/admin` — admins manage users, all VPS, nodes, deploy/resource plans, coupons, security logs, settings, and other admins.

## Setup

```bash
npm install
cp .env.example .env   # edit values, especially SESSION_SECRET and DEFAULT_ADMIN_PASSWORD
npm start
```

Server starts on `http://localhost:3000` (configurable via `PORT`).

- Client portal: `http://localhost:3000/client`
- Admin portal: `http://localhost:3000/admin`

On first run, a default admin account is created:
- username: `admin`
- password: value of `DEFAULT_ADMIN_PASSWORD` in `.env` (default `ChangeMe123!`)

**Change this password immediately after first login** (via the `users` table / re-registering, since there's no in-UI password-change flow yet — see Notes).

## Architecture

- `server.js` — Express app, sessions, static file serving for both portals.
- `db.js` — SQLite schema (better-sqlite3), mirrors the tables from `main.py` (users, vps, nodes, coins, plans, coupons, port forwards, security logs, trust scores, settings).
- `lxc.js` — Wraps the `lxc`/`incus` CLI the same way `execute_lxc()` did in the bot, for container start/stop/exec/snapshot/clone/etc. Set `LXC_BIN=incus` in `.env` if using Incus instead of LXD.
- `routes/auth.js` — shared register/login/logout/me endpoints for both portals.
- `routes/client.js` — user-facing API (`/api/client/...`), requires login.
- `routes/admin.js` — admin API (`/api/admin/...`), requires admin (some endpoints require main-admin).
- `middleware/auth.js` — session + admin/main-admin guards.
- `public/client/`, `public/admin/` — static single-page frontends (vanilla JS, no build step).
- `public/shared.css` — shared dark-theme styling for both portals.

## What was carried over from `main.py`

The original bot had ~9,600 lines and 150+ Discord commands. This dashboard reimplements the **core system** as REST APIs + UI, not a 1:1 command-by-command port:

- User auth (replacing Discord identity) with username/password + sessions
- VPS lifecycle: deploy from plan, start/stop/restart, exec, snapshot, renew, share, resize
- Admin VPS management: create for any user, suspend/unsuspend, delete, migrate, resize
- Coins/economy: balances, transactions, daily reward, leaderboard, coupon redemption
- Deploy plans & resource (upgrade) plans, full CRUD from admin
- Coupons: create/list/enable/disable/delete/stats
- Port forwarding: user-facing create/list/delete, admin delete
- Multi-node support: node list/create/delete, VPS assigned to a node
- Security logs & trust score / restriction system
- Admin management (main-admin only can add/remove admins)
- Global settings (thresholds, renewal cost)

Not carried over (bot-specific, has no web equivalent): Discord embeds/UI components, voice-state tracking, guild member join/leave hooks, Discord role assignment, in-chat command aliases/typo-correction, and the interactive Discord `!help` menu (the web nav sidebar replaces it).

## Notes / production hardening before real use

- Set a strong, random `SESSION_SECRET` in `.env`.
- Put this behind HTTPS/reverse proxy in production and set `TRUST_PROXY=true`.
- The `lxc`/`incus` binary must be installed and the server process must have permission to run it (this mirrors the same requirement the original Python bot had).
- Add a proper password-reset/change flow before exposing this to real users — it's not included yet.
- The container image chosen on deploy is inferred crudely from the plan name (`debian` in the name → Debian image, else Ubuntu 22.04). Wire this to your actual `os_version` selection if you need more OS choices in the deploy flow.
