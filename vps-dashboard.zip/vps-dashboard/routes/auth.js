const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../db');
const { isAdminId, isMainAdmin } = require('../middleware/auth');

const router = express.Router();

router.post('/register', (req, res) => {
  const { username, password, email } = req.body || {};
  if (!username || !password || password.length < 6) {
    return res.status(400).json({ error: 'Username and a password (6+ chars) are required' });
  }
  const existing = db.prepare('SELECT 1 FROM users WHERE username = ?').get(username);
  if (existing) return res.status(409).json({ error: 'Username already taken' });

  const userId = crypto.randomBytes(8).toString('hex');
  const hash = bcrypt.hashSync(password, 10);
  db.prepare(`INSERT INTO users (user_id, username, password_hash, email, created_at)
              VALUES (?, ?, ?, ?, ?)`).run(userId, username, hash, email || null, new Date().toISOString());

  db.prepare(`INSERT OR IGNORE INTO user_coins (user_id, balance, total_earned, total_spent, created_at)
              VALUES (?, 0, 0, 0, ?)`).run(userId, new Date().toISOString());

  req.session.userId = userId;
  req.session.username = username;
  res.json({ ok: true, userId, username });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password || '', user.password_hash)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  req.session.userId = user.user_id;
  req.session.username = user.username;
  res.json({
    ok: true,
    userId: user.user_id,
    username: user.username,
    isAdmin: isAdminId(user.user_id),
    isMainAdmin: isMainAdmin(user.user_id),
  });
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

router.get('/me', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
  res.json({
    userId: req.session.userId,
    username: req.session.username,
    isAdmin: isAdminId(req.session.userId),
    isMainAdmin: isMainAdmin(req.session.userId),
  });
});

module.exports = router;
