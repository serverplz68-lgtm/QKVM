require('dotenv').config();
const path = require('path');
const express = require('express');
const session = require('express-session');

const authRoutes = require('./routes/auth');
const clientRoutes = require('./routes/client');
const adminRoutes = require('./routes/admin');
const { requireLogin, requireAdmin } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'change-this-secret-in-.env',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
    secure: process.env.NODE_ENV === 'production' && process.env.TRUST_PROXY === 'true',
  },
}));

if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);

// Shared auth (register/login/logout/me)
app.use('/api/auth', authRoutes);

// Client-facing API (requires login)
app.use('/api/client', clientRoutes);

// Admin API (requires admin)
app.use('/api/admin', adminRoutes);

// Static frontends
app.use('/shared.css', express.static(path.join(__dirname, 'public/shared.css')));
app.use('/client', express.static(path.join(__dirname, 'public/client')));
app.use('/admin', express.static(path.join(__dirname, 'public/admin')));

// Page guards: serve the SPA shell, client-side JS handles auth redirect if not logged in
app.get('/', (req, res) => res.redirect('/client'));

app.get('/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use((req, res) => res.status(404).json({ error: 'Not found' }));

app.listen(PORT, () => {
  console.log(`VPS Dashboard running at http://localhost:${PORT}`);
  console.log(`  Client portal: http://localhost:${PORT}/client`);
  console.log(`  Admin portal:  http://localhost:${PORT}/admin`);
});
