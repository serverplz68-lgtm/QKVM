const express = require('express');
const db = require('../db');
const { lxc } = require('../lxc');
const { requireAdmin, requireMainAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAdmin);

// ---------- Dashboard / stats ----------

router.get('/stats', (req, res) => {
  const totals = {
    users: db.prepare('SELECT COUNT(*) c FROM users').get().c,
    vps: db.prepare('SELECT COUNT(*) c FROM vps').get().c,
    running: db.prepare("SELECT COUNT(*) c FROM vps WHERE status='running'").get().c,
    suspended: db.prepare('SELECT COUNT(*) c FROM vps WHERE suspended = 1').get().c,
    nodes: db.prepare('SELECT COUNT(*) c FROM nodes').get().c,
    coinsInCirculation: db.prepare('SELECT COALESCE(SUM(balance),0) s FROM user_coins').get().s,
  };
  res.json(totals);
});

// ---------- Nodes ----------

router.get('/nodes', (req, res) => res.json(db.prepare('SELECT * FROM nodes').all()));

router.post('/nodes', (req, res) => {
  const { name, location, total_vps, url, api_key } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name is required' });
  db.prepare(`INSERT INTO nodes (name, location, total_vps, tags, api_key, url, is_local)
              VALUES (?, ?, ?, '[]', ?, ?, 0)`).run(name, location || '', total_vps || 10, api_key || null, url || null);
  res.json({ ok: true });
});

router.delete('/nodes/:id', (req, res) => {
  const node = db.prepare('SELECT * FROM nodes WHERE id = ?').get(req.params.id);
  if (!node) return res.status(404).json({ error: 'Node not found' });
  if (node.is_local) return res.status(400).json({ error: 'Cannot delete local node' });
  db.prepare('DELETE FROM nodes WHERE id = ?').run(node.id);
  res.json({ ok: true });
});

// ---------- Users ----------

router.get('/users', (req, res) => {
  const rows = db.prepare(`
    SELECT u.user_id, u.username, u.email, u.created_at,
           COALESCE(c.balance,0) balance,
           (SELECT COUNT(*) FROM vps v WHERE v.user_id = u.user_id) vps_count
    FROM users u LEFT JOIN user_coins c ON c.user_id = u.user_id
    ORDER BY u.created_at DESC
  `).all();
  res.json(rows);
});

router.get('/users/:userId', (req, res) => {
  const user = db.prepare('SELECT user_id, username, email, created_at FROM users WHERE user_id = ?').get(req.params.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const coins = db.prepare('SELECT * FROM user_coins WHERE user_id = ?').get(req.params.userId);
  const vpsList = db.prepare('SELECT * FROM vps WHERE user_id = ?').all(req.params.userId);
  const trust = db.prepare('SELECT * FROM trust_scores WHERE user_id = ?').get(req.params.userId);
  res.json({ user, coins, vps: vpsList, trust: trust || { score: 100, restricted: 0 } });
});

// ---------- Coins admin ----------

function ensureCoins(userId) {
  db.prepare(`INSERT OR IGNORE INTO user_coins (user_id, balance, total_earned, total_spent, created_at)
              VALUES (?, 0, 0, 0, ?)`).run(userId, new Date().toISOString());
}

router.post('/users/:userId/coins/give', (req, res) => {
  ensureCoins(req.params.userId);
  const amount = parseInt(req.body?.amount, 10) || 0;
  const reason = req.body?.reason || 'Admin gift';
  db.prepare('UPDATE user_coins SET balance = balance + ?, total_earned = total_earned + ? WHERE user_id = ?')
    .run(amount, Math.max(amount, 0), req.params.userId);
  db.prepare(`INSERT INTO coin_transactions (user_id, amount, type, description, created_at)
              VALUES (?, ?, 'admin_give', ?, ?)`).run(req.params.userId, amount, reason, new Date().toISOString());
  res.json({ ok: true });
});

router.post('/users/:userId/coins/remove', (req, res) => {
  ensureCoins(req.params.userId);
  const amount = parseInt(req.body?.amount, 10) || 0;
  const reason = req.body?.reason || 'Admin removal';
  db.prepare('UPDATE user_coins SET balance = MAX(balance - ?, 0), total_spent = total_spent + ? WHERE user_id = ?')
    .run(amount, amount, req.params.userId);
  db.prepare(`INSERT INTO coin_transactions (user_id, amount, type, description, created_at)
              VALUES (?, ?, 'admin_remove', ?, ?)`).run(req.params.userId, -amount, reason, new Date().toISOString());
  res.json({ ok: true });
});

router.post('/users/:userId/coins/set', (req, res) => {
  ensureCoins(req.params.userId);
  const amount = parseInt(req.body?.amount, 10) || 0;
  db.prepare('UPDATE user_coins SET balance = ? WHERE user_id = ?').run(amount, req.params.userId);
  res.json({ ok: true });
});

// ---------- Ports admin ----------

router.post('/users/:userId/ports/add', (req, res) => {
  const amount = parseInt(req.body?.amount, 10) || 0;
  db.prepare(`INSERT INTO port_allocations (user_id, allocated_ports) VALUES (?, ?)
              ON CONFLICT(user_id) DO UPDATE SET allocated_ports = allocated_ports + ?`)
    .run(req.params.userId, amount, amount);
  res.json({ ok: true });
});

router.post('/users/:userId/ports/remove', (req, res) => {
  const amount = parseInt(req.body?.amount, 10) || 0;
  db.prepare(`UPDATE port_allocations SET allocated_ports = MAX(allocated_ports - ?, 0) WHERE user_id = ?`)
    .run(amount, req.params.userId);
  res.json({ ok: true });
});

router.delete('/ports/:forwardId', (req, res) => {
  db.prepare('DELETE FROM port_forwards WHERE id = ?').run(req.params.forwardId);
  res.json({ ok: true });
});

// ---------- VPS admin ----------

router.get('/vps', (req, res) => res.json(db.prepare('SELECT * FROM vps ORDER BY id DESC').all()));

router.post('/vps/create', (req, res) => {
  const { user_id, ram, cpu, disk, os_version, node_id, days } = req.body || {};
  if (!user_id || !ram || !cpu || !disk) return res.status(400).json({ error: 'user_id, ram, cpu, disk required' });
  const containerName = `vps-${user_id.slice(0, 6)}-${Date.now().toString(36)}`;
  const localNode = node_id || db.prepare('SELECT id FROM nodes WHERE is_local = 1').get().id;

  db.prepare(`INSERT INTO vps (user_id, node_id, container_name, ram, cpu, storage, config, os_version, status, created_at)
              VALUES (?, ?, ?, ?, ?, ?, '{}', ?, 'stopped', ?)`)
    .run(user_id, localNode, containerName, `${ram}GB`, `${cpu}`, `${disk}GB`, os_version || 'ubuntu:22.04', new Date().toISOString());

  const vpsRow = db.prepare('SELECT * FROM vps WHERE container_name = ?').get(containerName);
  if (days) {
    const expiresAt = new Date(Date.now() + parseInt(days, 10) * 86400000).toISOString();
    db.prepare('INSERT INTO vps_expiration (vps_id, expires_at, duration_days, auto_renew) VALUES (?, ?, ?, 0)')
      .run(vpsRow.id, expiresAt, days);
  }

  lxc.launch(containerName, os_version || 'ubuntu:22.04').then((r) => {
    db.prepare('UPDATE vps SET status = ? WHERE id = ?').run(r.ok ? 'running' : 'error', vpsRow.id);
    if (r.ok) lxc.setLimits(containerName, { cpu, ram, disk });
  });

  res.json({ ok: true, vps: vpsRow });
});

router.delete('/vps/:id', async (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const { reason } = req.body || {};
  await lxc.delete(v.container_name);
  db.prepare('DELETE FROM vps WHERE id = ?').run(v.id);
  db.prepare('DELETE FROM vps_expiration WHERE vps_id = ?').run(v.id);
  db.prepare('DELETE FROM port_forwards WHERE vps_container = ?').run(v.container_name);
  db.prepare(`INSERT INTO security_logs (user_id, activity_type, description, created_at)
              VALUES (?, 'vps_deleted', ?, ?)`).run(v.user_id, reason || 'Admin deletion', new Date().toISOString());
  res.json({ ok: true });
});

router.post('/vps/:id/suspend', (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const { reason } = req.body || {};
  const history = JSON.parse(v.suspension_history || '[]');
  history.push({ action: 'suspend', reason: reason || 'Admin action', at: new Date().toISOString() });
  db.prepare('UPDATE vps SET suspended = 1, suspension_history = ? WHERE id = ?')
    .run(JSON.stringify(history), v.id);
  lxc.stop(v.container_name);
  res.json({ ok: true });
});

router.post('/vps/:id/unsuspend', (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const history = JSON.parse(v.suspension_history || '[]');
  history.push({ action: 'unsuspend', at: new Date().toISOString() });
  db.prepare('UPDATE vps SET suspended = 0, suspension_history = ? WHERE id = ?')
    .run(JSON.stringify(history), v.id);
  res.json({ ok: true });
});

router.post('/vps/:id/whitelist', (req, res) => {
  const { whitelisted } = req.body || {};
  db.prepare('UPDATE vps SET whitelisted = ? WHERE id = ?').run(whitelisted ? 1 : 0, req.params.id);
  res.json({ ok: true });
});

router.post('/vps/:id/resize', (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const { ram, cpu, disk } = req.body || {};
  const updates = [];
  const params = [];
  if (ram) { updates.push('ram = ?'); params.push(`${ram}GB`); }
  if (cpu) { updates.push('cpu = ?'); params.push(`${cpu}`); }
  if (disk) { updates.push('storage = ?'); params.push(`${disk}GB`); }
  if (updates.length) {
    params.push(v.id);
    db.prepare(`UPDATE vps SET ${updates.join(', ')} WHERE id = ?`).run(...params);
    lxc.setLimits(v.container_name, { ram, cpu, disk });
  }
  res.json({ ok: true });
});

router.post('/vps/:id/migrate', async (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const { target_node_id } = req.body || {};
  const target = db.prepare('SELECT * FROM nodes WHERE id = ?').get(target_node_id);
  if (!target) return res.status(404).json({ error: 'Target node not found' });
  db.prepare('UPDATE vps SET node_id = ? WHERE id = ?').run(target_node_id, v.id);
  res.json({ ok: true });
});

router.post('/vps/:id/renew', (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const days = parseInt(req.body?.days, 10) || 1;
  const exp = db.prepare('SELECT * FROM vps_expiration WHERE vps_id = ?').get(v.id);
  const base = exp && new Date(exp.expires_at) > new Date() ? new Date(exp.expires_at) : new Date();
  const newExpiry = new Date(base.getTime() + days * 86400000).toISOString();
  if (exp) db.prepare('UPDATE vps_expiration SET expires_at = ? WHERE vps_id = ?').run(newExpiry, v.id);
  else db.prepare('INSERT INTO vps_expiration (vps_id, expires_at, duration_days, auto_renew) VALUES (?, ?, ?, 0)')
    .run(v.id, newExpiry, days);
  res.json({ ok: true, expires_at: newExpiry });
});

router.post('/vps/:id/exec', async (req, res) => {
  const v = db.prepare('SELECT * FROM vps WHERE id = ?').get(req.params.id);
  if (!v) return res.status(404).json({ error: 'VPS not found' });
  const { command } = req.body || {};
  const r = await lxc.exec(v.container_name, command || 'whoami');
  res.json({ ok: r.ok, stdout: r.stdout, stderr: r.stderr });
});

// ---------- Deploy plans ----------

router.get('/plans/deploy', (req, res) => res.json(db.prepare('SELECT * FROM deploy_plans ORDER BY id').all()));

router.post('/plans/deploy', (req, res) => {
  const { name, description, ram_gb, cpu_cores, disk_gb, duration_days, cost_coins, icon } = req.body || {};
  db.prepare(`INSERT INTO deploy_plans (name, description, ram_gb, cpu_cores, disk_gb, duration_days, cost_coins, icon, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(name, description || '', ram_gb, cpu_cores, disk_gb, duration_days, cost_coins, icon || '📦', new Date().toISOString());
  res.json({ ok: true });
});

router.put('/plans/deploy/:id', (req, res) => {
  const fields = ['name', 'description', 'ram_gb', 'cpu_cores', 'disk_gb', 'duration_days', 'cost_coins', 'active', 'icon'];
  const updates = [];
  const params = [];
  for (const f of fields) {
    if (req.body && req.body[f] !== undefined) { updates.push(`${f} = ?`); params.push(req.body[f]); }
  }
  if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
  params.push(req.params.id);
  db.prepare(`UPDATE deploy_plans SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  res.json({ ok: true });
});

router.delete('/plans/deploy/:id', (req, res) => {
  db.prepare('DELETE FROM deploy_plans WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Resource plans ----------

router.get('/plans/resource', (req, res) => res.json(db.prepare('SELECT * FROM resource_plans ORDER BY id').all()));

router.post('/plans/resource', (req, res) => {
  const { name, description, ram_gb, cpu_cores, disk_gb, cost_coins, icon } = req.body || {};
  db.prepare(`INSERT INTO resource_plans (name, description, ram_gb, cpu_cores, disk_gb, cost_coins, icon, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(name, description || '', ram_gb, cpu_cores, disk_gb, cost_coins, icon || '⚡', new Date().toISOString());
  res.json({ ok: true });
});

router.put('/plans/resource/:id', (req, res) => {
  const fields = ['name', 'description', 'ram_gb', 'cpu_cores', 'disk_gb', 'cost_coins', 'active', 'icon'];
  const updates = [];
  const params = [];
  for (const f of fields) {
    if (req.body && req.body[f] !== undefined) { updates.push(`${f} = ?`); params.push(req.body[f]); }
  }
  if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
  params.push(req.params.id);
  db.prepare(`UPDATE resource_plans SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  res.json({ ok: true });
});

router.delete('/plans/resource/:id', (req, res) => {
  db.prepare('DELETE FROM resource_plans WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Coupons ----------

router.get('/coupons', (req, res) => res.json(db.prepare('SELECT * FROM coupons ORDER BY id DESC').all()));

router.post('/coupons', (req, res) => {
  const { code, coins, max_uses, expires_in_days } = req.body || {};
  if (!code || !coins) return res.status(400).json({ error: 'code and coins are required' });
  const expiresAt = expires_in_days ? new Date(Date.now() + expires_in_days * 86400000).toISOString() : null;
  db.prepare(`INSERT INTO coupons (code, coins, max_uses, expires_at, created_at)
              VALUES (?, ?, ?, ?, ?)`).run(code, coins, max_uses || null, expiresAt, new Date().toISOString());
  res.json({ ok: true });
});

router.post('/coupons/:id/toggle', (req, res) => {
  const { active } = req.body || {};
  db.prepare('UPDATE coupons SET active = ? WHERE id = ?').run(active ? 1 : 0, req.params.id);
  res.json({ ok: true });
});

router.delete('/coupons/:id', (req, res) => {
  db.prepare('DELETE FROM coupons WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

router.get('/coupons/:id/stats', (req, res) => {
  const coupon = db.prepare('SELECT * FROM coupons WHERE id = ?').get(req.params.id);
  if (!coupon) return res.status(404).json({ error: 'Coupon not found' });
  const redemptions = db.prepare('SELECT * FROM coupon_redemptions WHERE coupon_id = ?').all(coupon.id);
  res.json({ coupon, redemptions });
});

// ---------- Security / trust ----------

router.get('/security-logs', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);
  const userId = req.query.user_id;
  const rows = userId
    ? db.prepare('SELECT * FROM security_logs WHERE user_id = ? ORDER BY id DESC LIMIT ?').all(userId, limit)
    : db.prepare('SELECT * FROM security_logs ORDER BY id DESC LIMIT ?').all(limit);
  res.json(rows);
});

router.get('/users/:userId/trust', (req, res) => {
  const row = db.prepare('SELECT * FROM trust_scores WHERE user_id = ?').get(req.params.userId);
  res.json(row || { user_id: req.params.userId, score: 100, restricted: 0 });
});

router.post('/users/:userId/trust/reset', (req, res) => {
  db.prepare(`INSERT INTO trust_scores (user_id, score, restricted) VALUES (?, 100, 0)
              ON CONFLICT(user_id) DO UPDATE SET score = 100, restricted = 0`).run(req.params.userId);
  res.json({ ok: true });
});

router.post('/users/:userId/restrict', (req, res) => {
  const { reason } = req.body || {};
  db.prepare(`INSERT INTO trust_scores (user_id, score, restricted) VALUES (?, 100, 1)
              ON CONFLICT(user_id) DO UPDATE SET restricted = 1`).run(req.params.userId);
  db.prepare(`INSERT INTO security_logs (user_id, activity_type, description, created_at)
              VALUES (?, 'restricted', ?, ?)`).run(req.params.userId, reason || 'Admin action', new Date().toISOString());
  res.json({ ok: true });
});

router.post('/users/:userId/unrestrict', (req, res) => {
  db.prepare(`INSERT INTO trust_scores (user_id, score, restricted) VALUES (?, 100, 0)
              ON CONFLICT(user_id) DO UPDATE SET restricted = 0`).run(req.params.userId);
  res.json({ ok: true });
});

// ---------- Settings ----------

router.get('/settings', (req, res) => {
  const rows = db.prepare('SELECT * FROM settings').all();
  res.json(Object.fromEntries(rows.map((r) => [r.key, r.value])));
});

router.post('/settings', (req, res) => {
  const entries = Object.entries(req.body || {});
  const stmt = db.prepare(`INSERT INTO settings (key, value) VALUES (?, ?)
                            ON CONFLICT(key) DO UPDATE SET value = excluded.value`);
  for (const [k, v] of entries) stmt.run(k, String(v));
  res.json({ ok: true });
});

// ---------- Admins (main-admin only) ----------

router.get('/admins', (req, res) => res.json(db.prepare('SELECT * FROM admins').all()));

router.post('/admins', requireMainAdmin, (req, res) => {
  const { user_id } = req.body || {};
  if (!user_id) return res.status(400).json({ error: 'user_id required' });
  db.prepare('INSERT OR IGNORE INTO admins (user_id) VALUES (?)').run(user_id);
  res.json({ ok: true });
});

router.delete('/admins/:userId', requireMainAdmin, (req, res) => {
  db.prepare('DELETE FROM admins WHERE user_id = ?').run(req.params.userId);
  res.json({ ok: true });
});

module.exports = router;
