import Database from 'better-sqlite3'; import fs from 'fs'; import path from 'path';
const dir=path.resolve('data'); fs.mkdirSync(dir,{recursive:true});
export const db=new Database(path.join(dir,'vps.db')); db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
