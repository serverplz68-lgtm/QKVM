const path = require('path');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');

const db = new Database(path.join(__dirname, 'data', 'vps.db'));
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 60000');
db.pragma('synchronous = NORMAL');

const MAIN_ADMIN_ID = process.env.MAIN_ADMIN_ID || 'admin';
const DEFAULT_ADMIN_PASSWORD = process.env.DEFAULT_ADMIN_PASSWORD || 'ChangeMe123!';

function init() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    user_id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    email TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS admins (
    user_id TEXT PRIMARY KEY
  );

  CREATE TABLE IF NOT EXISTS nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    location TEXT,
    total_vps INTEGER,
    tags TEXT DEFAULT '[]',
    api_key TEXT,
    url TEXT,
    is_local INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS vps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    node_id INTEGER NOT NULL DEFAULT 1,
    container_name TEXT UNIQUE NOT NULL,
    ram TEXT NOT NULL,
    cpu TEXT NOT NULL,
    storage TEXT NOT NULL,
    config TEXT NOT NULL,
    os_version TEXT DEFAULT 'ubuntu:22.04',
    status TEXT DEFAULT 'stopped',
    suspended INTEGER DEFAULT 0,
    whitelisted INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    shared_with TEXT DEFAULT '[]',
    suspension_history TEXT DEFAULT '[]'
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS port_allocations (
    user_id TEXT PRIMARY KEY,
    allocated_ports INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS port_forwards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    vps_container TEXT NOT NULL,
    vps_port INTEGER NOT NULL,
    host_port INTEGER NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS user_coins (
    user_id TEXT PRIMARY KEY,
    balance INTEGER DEFAULT 0,
    total_earned INTEGER DEFAULT 0,
    total_spent INTEGER DEFAULT 0,
    last_daily TEXT,
    invite_count INTEGER DEFAULT 0,
    message_count INTEGER DEFAULT 0,
    voice_minutes INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS coin_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    amount INTEGER NOT NULL,
    type TEXT NOT NULL,
    description TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS vps_expiration (
    vps_id INTEGER PRIMARY KEY,
    expires_at TEXT NOT NULL,
    duration_days INTEGER NOT NULL,
    auto_renew INTEGER DEFAULT 0,
    renewal_notified INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS deploy_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    ram_gb INTEGER NOT NULL,
    cpu_cores INTEGER NOT NULL,
    disk_gb INTEGER NOT NULL,
    duration_days INTEGER NOT NULL,
    cost_coins INTEGER NOT NULL,
    active INTEGER DEFAULT 1,
    icon TEXT DEFAULT '📦',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS resource_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    ram_gb INTEGER NOT NULL,
    cpu_cores INTEGER NOT NULL,
    disk_gb INTEGER NOT NULL,
    cost_coins INTEGER NOT NULL,
    active INTEGER DEFAULT 1,
    icon TEXT DEFAULT '⚡',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS coupons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    coins INTEGER NOT NULL,
    max_uses INTEGER,
    uses INTEGER DEFAULT 0,
    active INTEGER DEFAULT 1,
    expires_at TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS coupon_redemptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    coupon_id INTEGER NOT NULL,
    user_id TEXT NOT NULL,
    redeemed_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS security_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    activity_type TEXT NOT NULL,
    description TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS trust_scores (
    user_id TEXT PRIMARY KEY,
    score INTEGER DEFAULT 100,
    restricted INTEGER DEFAULT 0
  );
  `);

  const adminCount = db.prepare('SELECT COUNT(*) c FROM admins').get().c;
  if (adminCount === 0) {
    db.prepare('INSERT OR IGNORE INTO admins (user_id) VALUES (?)').run(MAIN_ADMIN_ID);
  }

  const localNode = db.prepare('SELECT COUNT(*) c FROM nodes WHERE is_local = 1').get().c;
  if (localNode === 0) {
    db.prepare(`INSERT INTO nodes (name, location, total_vps, tags, api_key, url, is_local)
                VALUES (?, ?, ?, ?, ?, ?, ?)`)
      .run('Local Node', 'Local', 100, '[]', null, null, 1);
  }

  const settingsInit = [['cpu_threshold', '90'], ['ram_threshold', '90']];
  const insSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  for (const [k, v] of settingsInit) insSetting.run(k, v);

  // Seed the main admin user account if it doesn't exist yet
  const existingAdminUser = db.prepare('SELECT * FROM users WHERE user_id = ?').get(MAIN_ADMIN_ID);
  if (!existingAdminUser) {
    const hash = bcrypt.hashSync(DEFAULT_ADMIN_PASSWORD, 10);
    db.prepare(`INSERT INTO users (user_id, username, password_hash, email, created_at)
                VALUES (?, ?, ?, ?, ?)`)
      .run(MAIN_ADMIN_ID, 'admin', hash, null, new Date().toISOString());
    console.log(`[setup] Created default admin user "admin" with password "${DEFAULT_ADMIN_PASSWORD}" — change this immediately.`);
  }
}

init();

module.exports = db;
